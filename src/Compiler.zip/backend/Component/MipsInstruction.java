package backend.Component;

public class MipsInstruction {
}
