package backend.Operand;

public class Operand {
}
