package backend.Operand;

public class Reg extends Operand {
}
