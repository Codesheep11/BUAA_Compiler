package Frontend.Parscial.ParseNodes;

public class Node {
}
