package Frontend.Parscial.ParseNodes;

import Frontend.Lexical.Word;

public class BType extends Node{
    private Word btype;

    public BType(Word btype) {
        this.btype = btype;
    }
}
