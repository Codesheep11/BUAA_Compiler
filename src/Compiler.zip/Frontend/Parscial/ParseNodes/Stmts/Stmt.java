package Frontend.Parscial.ParseNodes.Stmts;

import Frontend.Parscial.ParseNodes.Exp;
import Frontend.Parscial.ParseNodes.LVal;
import Frontend.Parscial.ParseNodes.Node;

public class Stmt extends Node {
}
